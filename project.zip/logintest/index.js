const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// ตั้งค่า Session
app.use(
  session({
    secret: 'mysecretkey',
    resave: false,
    saveUninitialized: true,
  })
);

// เชื่อมต่อฐานข้อมูล SQLite
const db = new sqlite3.Database('./database.db', (err) => {
  if (err) console.error(err.message);
  else console.log('Connected to SQLite Database');
});

// สร้างตาราง users ถ้ายังไม่มี
db.run(
  `CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    fullname TEXT,
    email TEXT
  )`
);

// Route: หน้า Login
app.get('/', (req, res) => {
  res.render('login', { error: null });
});

// Route: Process Login (ไม่ใช้ bcrypt)
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  db.get(
    'SELECT * FROM users WHERE username = ? AND password = ?',
    [username, password],
    (err, user) => {
      if (err) {
        console.error(err.message);
        return res.render('login', { error: 'Database error' });
      }
      if (!user) {
        return res.render('login', { error: 'Invalid credentials' });
      }

      req.session.user = user;
      res.redirect('/dashboard');
    }
  );
});

// Route: Dashboard (ดึงข้อมูลเฉพาะ user ที่ login)
app.get('/dashboard', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/');
  }

  const userId = req.session.user.id;
  db.get('SELECT * FROM users WHERE id = ?', [userId], (err, user) => {
    if (err) {
      console.error(err.message);
      res.send('Database error');
    } else {
      res.render('dashboard', { user });
    }
  });
});

app.get('/test', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/');
    }

    const userId = req.session.user.id;

    // ดึงข้อมูล order ของ user ที่ล็อกอิน
    db.all('SELECT * FROM orders WHERE user_id = ?', [userId], (err, orders) => {
        if (err) {
            console.error(err.message);
            res.send('Database error');
        } else {
            res.render('test', { user: req.session.user, orders });
        }
    });
});

  
// Route: Logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
